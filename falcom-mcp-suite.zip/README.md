# Falcom MCP Suite

Este projeto contém um gateway MCP unificado, um serviço TA‑LIB via FastAPI, e agentes
para organizar, documentar e executar tarefas de reestruturação em projetos. Ele pode
ser usado como base para integrar diferentes serviços e ferramentas via protocolo
Model Context Protocol (MCP).
