"""Agente documentador para projetos."""
