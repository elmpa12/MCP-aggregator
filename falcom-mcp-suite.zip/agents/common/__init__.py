"""Common utilities for Falcom agents."""
