"""Agents específicos para o projeto NTP."""
